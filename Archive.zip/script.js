function pagealert(){
    alert("Loading weather alert...");
}

function remove(){
    var myobj = document.getElementById("delete");
    myobj.remove();
}